import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { DashboardState } from '../types/dashboard';
import { v4 as uuidv4 } from 'uuid';

const initialState: DashboardState = {
  categories: [
    {
      id: '1',
      name: 'CSPM Executive Dashboard',
      widgets: [
        {
          id: uuidv4(),
          name: 'Cloud Accounts',
          content: JSON.stringify({
            type: 'donut',
            data: {
              labels: ['Connected', 'Not Connected'],
              datasets: [{
                data: [2, 1],
                backgroundColor: ['#4F46E5', '#E5E7EB']
              }]
            }
          }),
          categoryId: '1'
        },
        {
          id: uuidv4(),
          name: 'Cloud Account Risk Assessment',
          content: JSON.stringify({
            type: 'donut',
            data: {
              labels: ['Failed', 'Warning', 'Not Available', 'Passed'],
              datasets: [{
                data: [2659, 587, 92, 7012],
                backgroundColor: ['#EF4444', '#F59E0B', '#9CA3AF', '#10B981']
              }]
            }
          }),
          categoryId: '1'
        }
      ]
    },
    {
      id: '2',
      name: 'CWPP Dashboard',
      widgets: [
        {
          id: uuidv4(),
          name: 'Registry Scan',
          content: JSON.stringify({
            type: 'progress',
            data: {
              items: [
                {
                  label: 'Critical',
                  value: 75,
                  maxValue: 100,
                  color: 'bg-red-500'
                },
                {
                  label: 'High',
                  value: 45,
                  maxValue: 100,
                  color: 'bg-orange-500'
                }
              ]
            }
          }),
          categoryId: '2'
        }
      ]
    }
  ],
  searchTerm: '',
  isAddCategoryModalOpen: false
};

const dashboardSlice = createSlice({
  name: 'dashboard',
  initialState,
  reducers: {
    addWidget: (state, action: PayloadAction<{ categoryId: string; name: string; content: string }>) => {
      const category = state.categories.find(c => c.id === action.payload.categoryId);
      if (category) {
        category.widgets.push({
          id: uuidv4(),
          name: action.payload.name,
          content: action.payload.content,
          categoryId: action.payload.categoryId
        });
      }
    },
    removeWidget: (state, action: PayloadAction<{ categoryId: string; widgetId: string }>) => {
      const category = state.categories.find(c => c.id === action.payload.categoryId);
      if (category) {
        category.widgets = category.widgets.filter(w => w.id !== action.payload.widgetId);
      }
    },
    addCategory: (state, action: PayloadAction<{ name: string }>) => {
      state.categories.push({
        id: uuidv4(),
        name: action.payload.name,
        widgets: []
      });
    },
    removeCategory: (state, action: PayloadAction<string>) => {
      state.categories = state.categories.filter(c => c.id !== action.payload);
    },
    setSearchTerm: (state, action: PayloadAction<string>) => {
      state.searchTerm = action.payload;
    },
    setAddCategoryModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isAddCategoryModalOpen = action.payload;
    }
  }
});

export const {
  addWidget,
  removeWidget,
  addCategory,
  removeCategory,
  setSearchTerm,
  setAddCategoryModalOpen
} = dashboardSlice.actions;

export default dashboardSlice.reducer;