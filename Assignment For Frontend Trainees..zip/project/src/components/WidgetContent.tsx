import React from 'react';
import { DonutChart } from './widgets/DonutChart';
import { ProgressBar } from './widgets/ProgressBar';

interface WidgetContentProps {
  content: string;
}

export const WidgetContent: React.FC<WidgetContentProps> = ({ content }) => {
  try {
    const parsedContent = JSON.parse(content);

    switch (parsedContent.type) {
      case 'donut':
        return <DonutChart data={parsedContent.data} />;
      case 'progress':
        return (
          <div className="space-y-4">
            {parsedContent.data.items.map((item: any, index: number) => (
              <ProgressBar
                key={index}
                label={item.label}
                value={item.value}
                maxValue={item.maxValue}
                color={item.color}
              />
            ))}
          </div>
        );
      default:
        return <p className="text-gray-600 text-sm">{content}</p>;
    }
  } catch {
    return <p className="text-gray-600 text-sm">{content}</p>;
  }
};