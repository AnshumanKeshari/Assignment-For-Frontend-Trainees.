export interface Widget {
  id: string;
  name: string;
  content: string;
  categoryId: string;
}

export interface Category {
  id: string;
  name: string;
  widgets: Widget[];
}

export interface DashboardState {
  categories: Category[];
  searchTerm: string;
  isAddCategoryModalOpen: boolean;
}