import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { RootState } from './store/store';
import { removeWidget, removeCategory, setAddCategoryModalOpen } from './store/dashboardSlice';
import { AddWidgetModal } from './components/AddWidgetModal';
import { AddCategoryModal } from './components/AddCategoryModal';
import { SearchBar } from './components/SearchBar';
import { WidgetContent } from './components/WidgetContent';
import { Plus, X, Trash2 } from 'lucide-react';

function App() {
  const [selectedCategoryId, setSelectedCategoryId] = useState<string | null>(null);
  const { categories, searchTerm, isAddCategoryModalOpen } = useSelector((state: RootState) => state.dashboard);
  const dispatch = useDispatch();

  const filteredCategories = categories.map(category => ({
    ...category,
    widgets: category.widgets.filter(widget =>
      widget.name.toLowerCase().includes(searchTerm.toLowerCase())
    )
  }));

  const handleCategoryDelete = (categoryId: string) => {
    if (window.confirm('Are you sure you want to delete this category and all its widgets?')) {
      dispatch(removeCategory(categoryId));
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8">
          <div className="flex justify-between items-center mb-4">
            <h1 className="text-3xl font-bold text-gray-900">CSPM Dashboard</h1>
            <button
              onClick={() => dispatch(setAddCategoryModalOpen(true))}
              className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
            >
              <Plus className="w-5 h-5" />
              <span>Add Category</span>
            </button>
          </div>
          <SearchBar />
        </header>

        <div className="grid gap-6">
          {filteredCategories.map(category => (
            <div key={category.id} className="bg-white rounded-lg shadow-sm p-6">
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center space-x-4">
                  <h2 className="text-xl font-semibold text-gray-900">{category.name}</h2>
                  <button
                    onClick={() => handleCategoryDelete(category.id)}
                    className="p-2 hover:bg-red-100 rounded-full text-red-500"
                    title="Delete category"
                  >
                    <Trash2 className="w-5 h-5" />
                  </button>
                </div>
                <button
                  onClick={() => setSelectedCategoryId(category.id)}
                  className="flex items-center space-x-2 px-4 py-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  <span>Add Widget</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {category.widgets.map(widget => (
                  <div key={widget.id} className="bg-gray-50 rounded-lg p-4 relative group">
                    <button
                      onClick={() => dispatch(removeWidget({ categoryId: category.id, widgetId: widget.id }))}
                      className="absolute top-2 right-2 p-1 hover:bg-gray-200 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <X className="w-4 h-4 text-gray-500" />
                    </button>
                    <h3 className="font-medium text-gray-900 mb-2">{widget.name}</h3>
                    <WidgetContent content={widget.content} />
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>

        {selectedCategoryId && (
          <AddWidgetModal
            categoryId={selectedCategoryId}
            onClose={() => setSelectedCategoryId(null)}
          />
        )}
        
        {isAddCategoryModalOpen && <AddCategoryModal />}
      </div>
    </div>
  );
}

export default App;